<?php
// Database Connection Class
class Database {
    private $host;
    private $user;
    private $pass;
    private $dbname;
    
    public $conn;
    
    public function __construct($host = null, $user = null, $pass = null, $dbname = null) {
        $this->host = $host ?? (defined('DB_HOST') ? DB_HOST : 'localhost');
        $this->user = $user ?? (defined('DB_USER') ? DB_USER : 'root');
        $this->pass = $pass ?? (defined('DB_PASS') ? DB_PASS : '');
        $this->dbname = $dbname ?? (defined('DB_NAME') ? DB_NAME : 'flower_shop');
        
        $this->connect();
    }
    
    private function connect() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->dbname}", $this->user, $this->pass);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    public function query($sql) {
        return $this->conn->prepare($sql);
    }
    
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
}

// Don't create instance here - will be created in config.php after constants are defined
?>
