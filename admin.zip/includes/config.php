<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'flower_shop');

// Site Configuration
define('SITE_URL', 'http://localhost/p3/');
define('SITE_NAME', 'Online Flower & Greeting Delivery System');
define('ADMIN_EMAIL', 'admin@flowershop.com');

// Upload Configuration
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start Session
session_start();

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Include Database and Functions
require_once 'database.php';
require_once 'functions.php';
?>
