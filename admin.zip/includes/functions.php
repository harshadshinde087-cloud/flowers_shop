<?php
// Helper Functions

function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin_logged_in() {
    return isset($_SESSION['admin_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function generate_order_number() {
    return 'ORD' . date('Ymd') . strtoupper(substr(md5(uniqid()), 0, 6));
}

function format_price($price) {
    return '₹' . number_format($price, 2);
}

function get_cart_count() {
    if (!is_logged_in()) return 0;
    
    global $db;
    $stmt = $db->query("SELECT COUNT(*) as count FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch();
    return $result['count'];
}

function upload_image($file, $target_dir) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return false;
    }
    
    $filename = basename($file['name']);
    $target_file = $target_dir . time() . '_' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return $target_file;
    }
    return false;
}
?>
