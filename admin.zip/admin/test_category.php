<?php
require_once '../includes/config.php';

// Check if admin is logged in
if (!is_admin_logged_in()) {
    redirect('login.php');
}

$message = '';
$message_type = '';

// Add new category
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($name)) {
        $message = "Category name is required";
        $message_type = "danger";
    } elseif (empty($description)) {
        $message = "Category description is required";
        $message_type = "danger";
    } else {
        try {
            // Check if category already exists
            $check_stmt = $db->query("SELECT COUNT(*) as count FROM categories WHERE name = ?");
            $check_stmt->execute([$name]);
            $exists = $check_stmt->fetch()['count'];
            
            if ($exists > 0) {
                $message = "Category '$name' already exists!";
                $message_type = "warning";
            } else {
                $stmt = $db->query("INSERT INTO categories (name, description) VALUES (?, ?)");
                $result = $stmt->execute([$name, $description]);
                
                if ($result) {
                    $message = "Category '$name' added successfully!";
                    $message_type = "success";
                } else {
                    $message = "Failed to add category. Please try again.";
                    $message_type = "danger";
                }
            }
        } catch(PDOException $e) {
            $message = "Database error: " . $e->getMessage();
            $message_type = "danger";
        }
    }
}

// Get all categories
try {
    $stmt = $db->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $categories = [];
    $message = "Error fetching categories: " . $e->getMessage();
    $message_type = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Category Addition - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories.php" class="nav-link active">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Test Category Addition</h2>
                    <a href="categories.php" class="btn btn-outline-secondary">← Back to Categories</a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-4">Add New Category (Simple Form)</h5>
                            
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Category Name</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter category name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter category description" required></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary-custom w-100">Add Category</button>
                            </form>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-4">Current Categories (<?php echo count($categories); ?>)</h5>
                            
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($categories)): ?>
                                            <tr>
                                                <td colspan="2" class="text-center text-muted">No categories found</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($categories as $category): ?>
                                                <tr>
                                                    <td><strong><?php echo htmlspecialchars($category['name']); ?></strong></td>
                                                    <td><?php echo htmlspecialchars(substr($category['description'], 0, 50)); ?>...</td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
