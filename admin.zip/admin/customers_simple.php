<?php
// Standalone customers page - no dependencies
session_start();

// Simple database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'flower_shop';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_simple.php");
    exit();
}

// Get all customers
$customers = [];
try {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
    $customers = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = "Error fetching customers: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard_simple.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories_simple.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers_simple.php" class="nav-link active">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Customers Management</h2>
                    <div class="text-muted">
                        Total Customers: <strong><?php echo count($customers); ?></strong>
                    </div>
                </div>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Customers Table -->
                <div class="bg-white rounded p-4 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Joined Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($customers)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            No customers found. Customers will appear here when they register on your website.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($customers as $customer): ?>
                                        <tr>
                                            <td><?php echo $customer['id']; ?></td>
                                            <td><strong><?php echo htmlspecialchars($customer['name']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                            <td><?php echo $customer['phone'] ? htmlspecialchars($customer['phone']) : '<span class="text-muted">Not provided</span>'; ?></td>
                                            <td><?php echo $customer['address'] ? htmlspecialchars(substr($customer['address'], 0, 50)) . '...' : '<span class="text-muted">Not provided</span>'; ?></td>
                                            <td><?php echo date('M j, Y', strtotime($customer['created_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Customer Statistics -->
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="bg-white rounded p-4 shadow-sm text-center">
                            <h4 class="text-primary"><?php echo count($customers); ?></h4>
                            <p class="mb-0">Total Customers</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white rounded p-4 shadow-sm text-center">
                            <?php 
                            $recent_customers = 0;
                            $thirty_days_ago = date('Y-m-d', strtotime('-30 days'));
                            foreach ($customers as $customer) {
                                if ($customer['created_at'] >= $thirty_days_ago) {
                                    $recent_customers++;
                                }
                            }
                            ?>
                            <h4 class="text-success"><?php echo $recent_customers; ?></h4>
                            <p class="mb-0">New Customers (Last 30 days)</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white rounded p-4 shadow-sm text-center">
                            <?php 
                            $customers_with_phone = 0;
                            foreach ($customers as $customer) {
                                if (!empty($customer['phone'])) {
                                    $customers_with_phone++;
                                }
                            }
                            ?>
                            <h4 class="text-info"><?php echo $customers_with_phone; ?></h4>
                            <p class="mb-0">Customers with Phone</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
