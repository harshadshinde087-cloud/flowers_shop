<?php
// Standalone categories page - no dependencies
session_start();

// Simple database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'flower_shop';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if admin is logged in (simple check)
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_simple.php");
    exit();
}

$message = '';
$message_type = '';

// Add new category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($name)) {
        $message = "Category name is required";
        $message_type = "danger";
    } elseif (empty($description)) {
        $message = "Category description is required";
        $message_type = "danger";
    } else {
        try {
            // Check if category already exists
            $check_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM categories WHERE name = ?");
            $check_stmt->execute([$name]);
            $exists = $check_stmt->fetch()['count'];
            
            if ($exists > 0) {
                $message = "Category '$name' already exists!";
                $message_type = "warning";
            } else {
                $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
                $result = $stmt->execute([$name, $description]);
                
                if ($result) {
                    $message = "Category '$name' added successfully!";
                    $message_type = "success";
                } else {
                    $message = "Failed to add category. Please try again.";
                    $message_type = "danger";
                }
            }
        } catch(PDOException $e) {
            $message = "Database error: " . $e->getMessage();
            $message_type = "danger";
        }
    }
}

// Delete category
if (isset($_GET['delete'])) {
    $category_id = intval($_GET['delete']);
    try {
        // First check if there are products using this category
        $check_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = ?");
        $check_stmt->execute([$category_id]);
        $product_count = $check_stmt->fetch()['count'];
        
        if ($product_count > 0) {
            // Get category name for message
            $cat_stmt = $pdo->prepare("SELECT name FROM categories WHERE id = ?");
            $cat_stmt->execute([$category_id]);
            $category = $cat_stmt->fetch();
            $category_name = $category ? $category['name'] : 'Unknown';
            
            $message = "Cannot delete '$category_name' category. It has $product_count product(s) assigned. Please delete or reassign the products first.";
            $message_type = "warning";
        } else {
            // Safe to delete
            $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$category_id]);
            $message = "Category deleted successfully!";
            $message_type = "success";
        }
    } catch(PDOException $e) {
        $message = "Error deleting category: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Get all categories with product count
try {
    $stmt = $pdo->query("SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id ORDER BY c.name");
    $categories = $stmt->fetchAll();
    
    // If no categories exist, add default categories
    if (empty($categories)) {
        $default_categories = [
            ['Flowers', 'Fresh and beautiful flowers for every occasion'],
            ['Bouquets', 'Artistically arranged flower bouquets for special moments'],
            ['Greeting Cards', 'Beautiful greeting cards for all occasions and emotions'],
            ['Combos', 'Special flower and card combinations for perfect gifts'],
            ['Roses', 'Classic roses expressing love and romance'],
            ['Lilies', 'Elegant lilies for peace and serenity'],
            ['Carnations', 'Colorful carnations for gratitude and appreciation'],
            ['Sunflowers', 'Bright sunflowers bringing happiness and joy'],
            ['Tulips', 'Graceful tulips for elegant expressions'],
            ['Orchids', 'Exotic orchids for sophisticated gestures']
        ];
        
        foreach ($default_categories as $category) {
            $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
            $stmt->execute($category);
        }
        
        // Refresh categories list
        $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
        $categories = $stmt->fetchAll();
        
        $message = "Default categories have been added!";
        $message_type = "success";
    }
} catch(PDOException $e) {
    $categories = [];
    $message = "Error fetching categories: " . $e->getMessage();
    $message_type = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories Management - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories.php" class="nav-link active">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Categories Management</h2>
                    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        + Add New Category
                    </button>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Categories Table -->
                <div class="bg-white rounded p-4 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Products</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($categories)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No categories found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($categories as $category): ?>
                                        <tr>
                                            <td><?php echo $category['id']; ?></td>
                                            <td><strong><?php echo htmlspecialchars($category['name']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($category['description']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $category['product_count'] > 0 ? 'primary' : 'secondary'; ?>">
                                                    <?php echo $category['product_count']; ?> products
                                                </span>
                                            </td>
                                            <td><?php echo date('d M Y', strtotime($category['created_at'])); ?></td>
                                            <td>
                                                <?php if ($category['product_count'] == 0): ?>
                                                    <a href="categories_simple.php?delete=<?php echo $category['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled title="Cannot delete category with products">
                                                        Cannot Delete
                                                    </button>
                                                    <small class="text-muted d-block">Has <?php echo $category['product_count']; ?> product(s)</small>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="categories_simple.php">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Category Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary-custom">Add Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
