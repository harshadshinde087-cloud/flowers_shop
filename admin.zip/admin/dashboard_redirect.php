<?php
// Redirect to the working dashboard
header("Location: dashboard_simple.php");
exit();
?>
