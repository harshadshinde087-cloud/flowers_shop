<?php
// Redirect to the working dashboard
header("Location: dashboard_simple.php");
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard.php" class="nav-link active">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard Overview</h2>
                    <span class="text-muted">
                        <?php echo date('d M Y, h:i A'); ?>
                    </span>
                </div>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $total_products; ?></div>
                            <div class="text-muted">Total Products</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $total_orders; ?></div>
                            <div class="text-muted">Total Orders</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $total_customers; ?></div>
                            <div class="text-muted">Total Customers</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $pending_orders; ?></div>
                            <div class="text-muted">Pending Orders</div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Recent Orders -->
                    <div class="col-md-8 mb-4">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-3">Recent Orders</h5>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                            <tr>
                                                <td><?php echo $order['order_number']; ?></td>
                                                <td><?php echo $order['customer_name'] ?? 'Guest'; ?></td>
                                                <td><?php echo format_price($order['total_amount']); ?></td>
                                                <td>
                                                    <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                                        <?php echo $order['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center mt-3">
                                <a href="orders.php" class="btn btn-primary-custom">View All Orders</a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Low Stock Alert -->
                    <div class="col-md-4 mb-4">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-3 text-warning">⚠️ Low Stock Alert</h5>
                            <?php if (empty($low_stock)): ?>
                                <p class="text-muted">All products are well stocked!</p>
                            <?php else: ?>
                                <?php foreach ($low_stock as $product): ?>
                                    <div class="alert alert-warning mb-2">
                                        <strong><?php echo $product['name']; ?></strong><br>
                                        <small>Stock: <?php echo $product['stock_quantity']; ?> units</small>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
