<?php
// Standalone dashboard - no dependencies
session_start();

// Simple database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'flower_shop';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_simple.php");
    exit();
}

// Get dashboard statistics
$total_products = 0;
$total_orders = 0;
$total_customers = 0;
$pending_orders = 0;
$recent_orders = [];
$low_stock = [];

try {
    // Check if tables exist
    $tables_query = $pdo->query("SHOW TABLES");
    $existing_tables = [];
    while ($table = $tables_query->fetch()) {
        $existing_tables[] = array_values($table)[0];
    }
    
    // Total products
    if (in_array('products', $existing_tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM products");
        $result = $stmt->fetch();
        $total_products = $result ? $result['count'] : 0;
    }
    
    // Total orders
    if (in_array('orders', $existing_tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders");
        $result = $stmt->fetch();
        $total_orders = $result ? $result['count'] : 0;
        
        // Pending orders
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Pending'");
        $result = $stmt->fetch();
        $pending_orders = $result ? $result['count'] : 0;
        
        // Recent orders
        $stmt = $pdo->query("SELECT o.*, u.name as customer_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
        $recent_orders = $stmt->fetchAll();
    }
    
    // Total customers
    if (in_array('users', $existing_tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $result = $stmt->fetch();
        $total_customers = $result ? $result['count'] : 0;
    }
    
    // Low stock products
    if (in_array('products', $existing_tables)) {
        $stmt = $pdo->query("SELECT * FROM products WHERE stock_quantity < 10 ORDER BY stock_quantity ASC LIMIT 5");
        $low_stock = $stmt->fetchAll();
    }
    
} catch(PDOException $e) {
    $error = "Error fetching dashboard data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard_simple.php" class="nav-link active">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories_simple.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <span class="text-muted">
                        <?php echo date('l, F j, Y'); ?>
                    </span>
                </div>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-primary">
                                🌹
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $total_products; ?></h3>
                                <p>Total Products</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-success">
                                📦
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $total_orders; ?></h3>
                                <p>Total Orders</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-warning">
                                ⏰
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $pending_orders; ?></h3>
                                <p>Pending Orders</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-info">
                                👥
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $total_customers; ?></h3>
                                <p>Total Customers</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Recent Orders -->
                    <div class="col-md-8 mb-4">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-3">Recent Orders</h5>
                            
                            <?php if (empty($recent_orders)): ?>
                                <p class="text-muted">No orders found</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Order #</th>
                                                <th>Customer</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recent_orders as $order): ?>
                                                <tr>
                                                    <td><?php echo $order['order_number']; ?></td>
                                                    <td><?php echo $order['customer_name'] ?? 'Guest'; ?></td>
                                                    <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php echo $order['status'] == 'Pending' ? 'warning' : ($order['status'] == 'Delivered' ? 'success' : 'info'); ?>">
                                                            <?php echo $order['status']; ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Low Stock Alert -->
                    <div class="col-md-4 mb-4">
                        <div class="bg-white rounded p-4 shadow-sm">
                            <h5 class="mb-3">Low Stock Alert</h5>
                            
                            <?php if (empty($low_stock)): ?>
                                <p class="text-muted">All products well stocked</p>
                            <?php else: ?>
                                <?php foreach ($low_stock as $product): ?>
                                    <div class="alert alert-warning alert-sm mb-2">
                                        <strong><?php echo htmlspecialchars($product['name']); ?></strong><br>
                                        <small>Stock: <?php echo $product['stock_quantity']; ?> units</small>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
