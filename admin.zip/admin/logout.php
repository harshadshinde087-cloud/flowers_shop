<?php
require_once '../includes/config.php';

// Destroy admin session
session_unset();
session_destroy();

// Redirect to login page
redirect('login.php');
?>
