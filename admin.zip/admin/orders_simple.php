<?php
// Standalone orders page - no dependencies
session_start();

// Simple database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'flower_shop';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_simple.php");
    exit();
}

// Handle order status update
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_status') {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$status, $order_id]);
        $message = "Order status updated successfully!";
        $message_type = "success";
    } catch(PDOException $e) {
        $message = "Error updating order: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Get all orders with customer details
$orders = [];
try {
    $stmt = $pdo->query("SELECT o.*, u.name as customer_name, u.email as customer_email 
                        FROM orders o 
                        LEFT JOIN users u ON o.user_id = u.id 
                        ORDER BY o.created_at DESC");
    $orders = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = "Error fetching orders: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard_simple.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products_simple.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories_simple.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders_simple.php" class="nav-link active">
                            📦 Orders
                        </a>
                        <a href="customers_simple.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Orders Management</h2>
                    <div class="text-muted">
                        Total Orders: <strong><?php echo count($orders); ?></strong>
                    </div>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Orders Table -->
                <div class="bg-white rounded p-4 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Payment</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($orders)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No orders found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td><strong><?php echo $order['order_number']; ?></strong></td>
                                            <td>
                                                <?php echo htmlspecialchars($order['customer_name'] ?? 'Guest'); ?><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($order['customer_email'] ?? ''); ?></small>
                                            </td>
                                            <td><strong>$<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                            <td>
                                                <span class="badge bg-<?php echo $order['status'] == 'Pending' ? 'warning' : ($order['status'] == 'Delivered' ? 'success' : ($order['status'] == 'Cancelled' ? 'danger' : 'info')); ?>">
                                                    <?php echo $order['status']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $order['payment_method']; ?></td>
                                            <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#orderDetailsModal<?php echo $order['id']; ?>">
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                        
                                        <!-- Order Details Modal -->
                                        <div class="modal fade" id="orderDetailsModal<?php echo $order['id']; ?>" tabindex="-1">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Order Details - <?php echo $order['order_number']; ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row mb-3">
                                                            <div class="col-md-6">
                                                                <h6>Customer Information</h6>
                                                                <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name'] ?? 'Guest'); ?></p>
                                                                <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email'] ?? ''); ?></p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <h6>Order Information</h6>
                                                                <p><strong>Order Number:</strong> <?php echo $order['order_number']; ?></p>
                                                                <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
                                                                <p><strong>Total:</strong> $<?php echo number_format($order['total_amount'], 2); ?></p>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <h6>Shipping Address</h6>
                                                            <p><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <h6>Update Status</h6>
                                                                    <form method="POST" action="orders_simple.php">
                                                                        <input type="hidden" name="action" value="update_status">
                                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                                        <div class="row">
                                                                            <div class="col-md-8">
                                                                                <select class="form-control" name="status">
                                                                                    <option value="Pending" <?php echo $order['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                                                    <option value="Processing" <?php echo $order['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                                                                    <option value="Shipped" <?php echo $order['status'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                                                                                    <option value="Delivered" <?php echo $order['status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                                                                    <option value="Cancelled" <?php echo $order['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <button type="submit" class="btn btn-primary-custom w-100">Update</button>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                        </div>
                                                        
                                                        <div>
                                                            <h6>Order Items</h6>
                                                            <?php
                                                            try {
                                                                $items_stmt = $pdo->prepare("SELECT oi.*, p.name as product_name 
                                                                                           FROM order_items oi 
                                                                                           LEFT JOIN products p ON oi.product_id = p.id 
                                                                                           WHERE oi.order_id = ?");
                                                                $items_stmt->execute([$order['id']]);
                                                                $order_items = $items_stmt->fetchAll();
                                                                
                                                                if (!empty($order_items)):
                                                            ?>
                                                                <div class="table-responsive">
                                                                    <table class="table table-sm">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Product</th>
                                                                                <th>Quantity</th>
                                                                                <th>Price</th>
                                                                                <th>Total</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php foreach ($order_items as $item): ?>
                                                                                <tr>
                                                                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                                                    <td><?php echo $item['quantity']; ?></td>
                                                                                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                                                                                    <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                                                                </tr>
                                                                            <?php endforeach; ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            <?php else: ?>
                                                                <p class="text-muted">No items found</p>
                                                            <?php endif; ?>
                                                            <?php } catch(PDOException $e) {
                                                                echo "<p class='text-danger'>Error loading order items</p>";
                                                            } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
