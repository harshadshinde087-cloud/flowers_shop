<?php
// Redirect to the working orders page
header("Location: orders_simple.php");
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products.php" class="nav-link">
                            🌹 Products
                        </a>
                        <a href="categories.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link active">
                            📦 Orders
                        </a>
                        <a href="customers.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Orders Management</h2>
                    <span class="text-muted">
                        Total Orders: <?php echo count($orders); ?>
                    </span>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Orders Table -->
                <div class="bg-white rounded p-4 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Payment</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo $order['order_number']; ?></strong>
                                        </td>
                                        <td>
                                            <?php echo $order['customer_name'] ?? 'Guest Customer'; ?><br>
                                            <small class="text-muted"><?php echo $order['customer_email'] ?? 'No email'; ?></small>
                                        </td>
                                        <td><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></td>
                                        <td><?php echo format_price($order['total_amount']); ?></td>
                                        <td>
                                            <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                                <?php echo $order['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $order['payment_method']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#viewOrderModal<?php echo $order['id']; ?>">
                                                View
                                            </button>
                                            <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#updateStatusModal<?php echo $order['id']; ?>">
                                                Update
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Order Modals -->
    <?php foreach ($orders as $order): ?>
        <?php
        // Get order items
        $stmt = $db->query("SELECT oi.*, p.name as product_name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $stmt->execute([$order['id']]);
        $order_items = $stmt->fetchAll();
        ?>
        
        <!-- View Order Modal -->
        <div class="modal fade" id="viewOrderModal<?php echo $order['id']; ?>" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Order Details - <?php echo $order['order_number']; ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Customer:</strong> <?php echo $order['customer_name'] ?? 'Guest'; ?><br>
                                <strong>Email:</strong> <?php echo $order['customer_email'] ?? 'N/A'; ?><br>
                                <strong>Payment:</strong> <?php echo $order['payment_method']; ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Order Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?><br>
                                <strong>Status:</strong> <span class="order-status status-<?php echo strtolower($order['status']); ?>"><?php echo $order['status']; ?></span><br>
                                <strong>Total Amount:</strong> <?php echo format_price($order['total_amount']); ?>
                            </div>
                        </div>
                        
                        <?php if ($order['shipping_address']): ?>
                            <div class="mb-3">
                                <strong>Shipping Address:</strong><br>
                                <?php echo nl2br($order['shipping_address']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <h6>Order Items:</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order_items as $item): ?>
                                        <tr>
                                            <td><?php echo $item['product_name']; ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td><?php echo format_price($item['price']); ?></td>
                                            <td><?php echo format_price($item['quantity'] * $item['price']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Update Status Modal -->
        <div class="modal fade" id="updateStatusModal<?php echo $order['id']; ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Update Order Status - <?php echo $order['order_number']; ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            
                            <div class="mb-3">
                                <label for="status" class="form-label">Order Status</label>
                                <select class="form-control" id="status" name="status" required>
                                    <option value="Pending" <?php echo $order['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Processing" <?php echo $order['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="Shipped" <?php echo $order['status'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                                    <option value="Delivered" <?php echo $order['status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="Cancelled" <?php echo $order['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary-custom">Update Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
