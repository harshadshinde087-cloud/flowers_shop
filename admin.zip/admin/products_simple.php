<?php
// Standalone products page - no dependencies
session_start();

// Simple database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'flower_shop';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_simple.php");
    exit();
}

// Handle product operations
$message = '';
$message_type = '';

// Add new product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $stock_quantity = intval($_POST['stock_quantity'] ?? 0);
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    
    // Handle image upload
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'product_' . time() . '.' . $ext;
            $upload_path = '../uploads/' . $new_filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $image = $new_filename;
            }
        }
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category_id, stock_quantity, image, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $category_id, $stock_quantity, $image, $is_featured]);
        
        $message = "Product added successfully!";
        $message_type = "success";
    } catch(PDOException $e) {
        $message = "Error adding product: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Delete product
if (isset($_GET['delete'])) {
    $product_id = intval($_GET['delete']);
    try {
        // Check if product is referenced in order items
        $check_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM order_items WHERE product_id = ?");
        $check_stmt->execute([$product_id]);
        $order_count = $check_stmt->fetch()['count'];
        
        if ($order_count > 0) {
            // Get product name for message
            $prod_stmt = $pdo->prepare("SELECT name FROM products WHERE id = ?");
            $prod_stmt->execute([$product_id]);
            $product = $prod_stmt->fetch();
            $product_name = $product ? $product['name'] : 'Unknown';
            
            $message = "Cannot delete '$product_name' product. It is referenced in $order_count order(s). Please delete the orders first or mark the product as out of stock.";
            $message_type = "warning";
        } else {
            // Check if product is in any user's cart
            $cart_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM cart WHERE product_id = ?");
            $cart_stmt->execute([$product_id]);
            $cart_count = $cart_stmt->fetch()['count'];
            
            if ($cart_count > 0) {
                // Remove from cart first, then delete product
                $cart_delete_stmt = $pdo->prepare("DELETE FROM cart WHERE product_id = ?");
                $cart_delete_stmt->execute([$product_id]);
            }
            
            // Safe to delete
            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $message = "Product deleted successfully!";
            $message_type = "success";
        }
    } catch(PDOException $e) {
        $message = "Error deleting product: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Get all products with categories and order count
try {
    $stmt = $pdo->query("SELECT p.*, c.name as category_name, (SELECT COUNT(*) FROM order_items oi WHERE oi.product_id = p.id) as order_count FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC");
    $products = $stmt->fetchAll();
    
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = "Error fetching data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - Flower Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 admin-sidebar p-0">
                <div class="p-4">
                    <h4>🌸 Admin Panel</h4>
                    <p class="mb-4">Welcome, <?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></p>
                    
                    <nav class="nav flex-column">
                        <a href="dashboard_simple.php" class="nav-link">
                            📊 Dashboard
                        </a>
                        <a href="products_simple.php" class="nav-link active">
                            🌹 Products
                        </a>
                        <a href="categories_simple.php" class="nav-link">
                            📁 Categories
                        </a>
                        <a href="orders.php" class="nav-link">
                            📦 Orders
                        </a>
                        <a href="customers_simple.php" class="nav-link">
                            👥 Customers
                        </a>
                        <a href="logout.php" class="nav-link">
                            🚪 Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 admin-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Products Management</h2>
                    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        + Add New Product
                    </button>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Products Table -->
                <div class="bg-white rounded p-4 shadow-sm">
                    <div class="mb-3">
                        <small class="text-info">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Note:</strong> Products with orders cannot be deleted to maintain data integrity. 
                            Instead, you can set stock to 0 to make them unavailable, or delete the orders first.
                        </small>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Featured</th>
                                    <th>Orders</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($products)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">No products found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td>
                                                <?php if ($product['image']): ?>
                                                    <img src="../uploads/<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div style="width: 50px; height: 50px; background: #f0f0f0; display: flex; align-items: center; justify-content: center;">🌹</div>
                                                <?php endif; ?>
                                            </td>
                                            <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                            <td><?php echo $product['category_name'] ?? 'Uncategorized'; ?></td>
                                            <td>$<?php echo number_format($product['price'], 2); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $product['stock_quantity'] > 10 ? 'success' : ($product['stock_quantity'] > 0 ? 'warning' : 'danger'); ?>">
                                                    <?php echo $product['stock_quantity']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($product['is_featured']): ?>
                                                    <span class="badge bg-primary">Featured</span>
                                                <?php else: ?>
                                                    <span class="text-muted">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo $product['order_count'] > 0 ? 'info' : 'secondary'; ?>">
                                                    <?php echo $product['order_count']; ?> orders
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($product['order_count'] == 0): ?>
                                                    <a href="products_simple.php?delete=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled title="Cannot delete product with orders">
                                                        Cannot Delete
                                                    </button>
                                                    <small class="text-muted d-block">Has <?php echo $product['order_count']; ?> order(s)</small>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="products_simple.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Product Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="category_id" class="form-label">Category</label>
                                    <select class="form-control" id="category_id" name="category_id" required>
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="price" class="form-label">Price ($)</label>
                                    <input type="number" class="form-control" id="price" name="price" step="0.01" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="stock_quantity" class="form-label">Stock Quantity</label>
                                    <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="image" class="form-label">Product Image</label>
                                    <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured">
                                <label class="form-check-label" for="is_featured">
                                    Mark as Featured Product
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary-custom">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
